<?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL|E_STRICT);

    session_start();

$host = 'db.ethereallab.app';
$db   = 'bw286';
$user = 'bw286';
$pass = 'm8Wb62hnHxvQ';
$charset = 'utf8mb4';
$count = 0;
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
}


    if(isset($_POST['submit']))//check if user exists in sql db
    {
        $user_id = trim($_POST['uid']); 
        $password = trim($_POST['pw']);  
        if(empty($user_id)){
            $error = "Empty username";
            $_SESSION["error"] = $error;
            header("Location: index.php?Username is empty");
            exit();
        }
        if(empty($password)){
            $error = "Empty password";
            $_SESSION["error"] = $error;
            header("Location: index.php");
            exit();
        }
        
        $result = $pdo->query("SELECT email, password FROM Users WHERE email=$user_id");

        if ($result->rowCount() == 1){
            $row = $stmt->fetch();
            // verify password
            if (password_verify($password, $row["password"])){
                //login successful
                echo 'Logged in';
                $_SESSION["logged_in"]=true;
                $_SESSION["email"]=$row["email"];
                header("Location: other.php");
                exit();
            
                
            }
            else {
                //login unsuccessful
                $error = "Invalid email/password";
                $_SESSION["error"] = $error;
                echo 'Email or Password is incorrect';
                header("Location: index.php");
                exit();
            }
        }
        else {
            //login unsuccessful
            $error = "Invalid email/password";
            $_SESSION["error"] = $error;
            echo 'Email or Password is incorrect';
            header("Location: index.php");
            exit();
        }
    }
    else if(isset($_POST['submitNewUser'])){//insert new user in sql db
        $user_id = $_POST['uid']; 
        $password = $_POST['pw'];
        $password = password_hash($password, PASSWORD_DEFAULT);
        
        //$created = date("Y/m/d");
        //$modified = false;
        
        if(empty($user_id)){
            $error = "Empty user registration";
            $_SESSION["error"] = $error;
            header("Location: index.php");
            exit();
        }
        if(empty($password)){
            $error = "Empty password registration";
            $_SESSION["error"] = $error;
            header("Location: index.php");
            exit();
        }
        $data = [ 
            'email' => $user_id,
            'password' => $password,                        
        ];
        $user_insert = "INSERT INTO Users (email, password) VALUES (:email, :password)";
        $stmt = $pdo->prepare($user_insert);
        $stmt->execute($data);
        header("Location: index.php");
    }
?>

