<?php include("login.php")?>
<script src="pageutil.js"></script>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login_Page</title>
  </head>

  <body>
    <div align="center">
      <h2>Welcome to the main page</h2>
      <input type="button" value="Go to back to login page" onclick="change_page('index.php')"/>
    </div>	

  </body>
</html>

